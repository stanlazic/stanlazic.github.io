
## ---------------------------------------------------------
## Bayesian machine learning model for DILI
## Stanley E. Lazic
## 2019-06-01
## ---------------------------------------------------------

library(rstan)
library(recipes)
library(ggridges)

options(mc.cores = parallel::detectCores())
rstan_options(auto_write = TRUE)


## load helper functions
source("functions.R")



## read in data
d <-  read.delim("DILI_raw_data.txt")


## ---------------------------------------------------------
## Preprocessing
## ---------------------------------------------------------

## colour information for plotting: convert to character
d$cols <- as.character(d$cols)


## estimate means and SDs for predictors to standardise
parms <- select(d, -Gal) %>%            # drop Gal measurement (not used)
    recipe(roles=c(rep("ID", 2),        # define what the columns are
                   rep("predictor", 7),
                   rep("ID", 3))) %>% 
    step_center(all_predictors()) %>%
    step_scale(all_predictors()) %>%
    prep(training = d)

## apply to training data
d2 <- bake(parms, new_data = d, composition="data.frame")


## test data for two new compounds
new.compounds <- data.frame(
    name=c("CPD_A", "CPD_B"), 
    AZID=c("AZD123", "AZD456"),
    Spher=c(250, 250),
    BSEP=c(314, 1000),
    THP1=c(250, 250),
    Glu=c(250, 250),
    Glu.Gal=c(1, 1),
    ClogP=c(2.501, 3.900),
    BA=c(-1, -1),
    log10.cmax=c(0.5051500, 0.7075702)
)


## standardise
new.cpds.scaled <- bake(parms, new_data = new.compounds, composition="data.frame")



## ---------------------------------------------------------
## Define and fit model
## ---------------------------------------------------------


## specify design matrix (intercept not needed; included as cutpoints)
X <- model.matrix(~ 0 + (Spher + BSEP + THP1 + Glu + Glu.Gal + ClogP + BA)^2 +
                      log10.cmax, data=d2)

## compile model
mod <- stan_model("ML_model.stan")


## draw samples from posterior
m1 <- sampling(mod,
               data=list(N=nrow(X),
                         P=ncol(X),
                         y=d2$dili.sev,
                         X=X,
                         sigma_prior=1,
                         
                         make_pred = 1,
                         N_pred=nrow(X), # (predict the training data)
                         X_pred=X),
               iter=10000, chains=3, seed=123)



## extract posterior samples
pr <- extract(m1)

## extract predicted (training) values and convert to 0-1 scale
post <- invlogit(pr$eta)

## mean cutpoints
c1 <- mean(invlogit(pr$cutpoints[,1]))
c2 <- mean(invlogit(pr$cutpoints[,2]))

## calculate average profile for DILI category 3 compounds
avg3 <- matrix(NA, nrow=512, ncol=length(which(d2$dili.sev==3)))

cnt <- 1
for(i in which(d2$dili.sev==3)){
    dens <- density(post[,i], adjust=1.5, from=0, to=1)
    avg3[, cnt] <- dens$y
    cnt <- cnt + 1
}

avg3 <- apply(avg3, 1, mean)

avg3 <- data.frame(y=avg3, x=dens$x)




## ---------------------------------------------------------
## Predictions for training compounds
## ---------------------------------------------------------

    
pdf("predictions.pdf", height=5, width=10)

for(i in 1:ncol(post)){

    par(las=1,
        mar=c(4.5,1,3,1))

    layout(matrix(c(1,1,2,3), 2, 2))

    ## calculate all summary statistics
    res <- make.calcs(post[,i], pr$ypred[,i])
    
    ## First panel: density plot
    postplot(res$dens, main=d2$Drug[i], percs=res$percs)
    
    ## Second panel: numeric summaries
    make.legend(res, true.category=d2$dili.sev[i], cols=as.character(d2$cols[i]))
        
    ## Third panel: assay results
    par(mar=c(3,4.5,0.1,4.5))

    plot.dots(y=8, x=d[i, "Spher"], xlim=rev(c(2.04, 250)))
    
    par(new=TRUE)
    plot.dots(y=7, x=d[i, "BSEP"], xlim=rev(c(0.3, 1000)))

    par(new=TRUE)
    plot.dots(y=6, x=d[i, "THP1"], xlim=rev(c(0.01, 250)))
    
    par(new=TRUE)
    plot.dots(y=5, x=d[i, "Glu"], xlim=rev(c(11.8, 250)))

    par(new=TRUE)
    plot.dots(y=4, x=d[i, "Glu.Gal"], xlim=c(0.3, 5.2))

    par(new=TRUE)
    plot.dots(y=3, x=d[i, "ClogP"], xlim=c(-5.6, 9.7))

    par(new=TRUE)
    plot.dots(y=2, x=d[i, "log10.cmax"], xlim=c(-2, 3.0454))

    par(new=TRUE)
    plot.dots(y=1, x=d[i, "BA"], xlim=c(-1, 1))
 
    axis(2, at=8:1, labels=c("Spher","BSEP","THP1","Glu","Glu/Gal","ClogP","Cmax","BA"),
         tick=FALSE)
        axis(4, at=8:1, labels=c(d$Spher[i],
                             d$BSEP[i],
                             d$THP1[i],
                             d$Glu[i],
                             d$Glu.Gal[i],
                             d$ClogP[i],
                             signif(10^d$log10.cmax[i], 3),
                             d$BA[i]),
         tick=FALSE)
    axis(1, at=c(-1, 1), labels=c("Low risk","High risk"))
    mtext("Assay result", side=1, line=2)

}

dev.off()



## calculate median + 95% HDI for all compounds
post.med <- apply(post, 2, median)
names(post.med) <- d$Drug

## calculate 95% highest posterior density interval (similar to a 95% CI)
post.ci <-  coda::HPDinterval(coda::as.mcmc(post))

## index to order compounds for plotting
ind <- order(post.med)


png("all_predictions.png", height=5, width=12, res=100, units="in")
par(las=1,
    mfrow=c(1, 2),
    mar=c(5, 5, 3, 1))

layout(matrix(c(1,2), 1, 2), width=0.65, 1)

beeswarm::beeswarm(apply(post, 2, median) ~ d$dili.sev,
                   pch=16, ylim=c(0,1), method="center",
                   pwcol=d$cols, ylab="Predicted DILI severity",
                   xlab="True DILI category", main="Median of posterior")
abline(h=c(c1, c2), lty=2)
mtext("A", side=3, adj=0, line=1.5, font=2, cex=1.2)

plot(post.med[ind], pch=18, ylim=c(0,1), ylab="Predicted DILI severity\n+ 95% CI",
     col=d$cols[ind], main="Median of posterior", 
     xaxt="n", xlab="Compounds (ordered)")

segments(c(1:nrow(d)), post.ci[ind, 1],
         c(1:nrow(d)), post.ci[ind, 2],
         col=d$cols[ind])

abline(h=c(c1, c2), lty=2, col=c("black"))
mtext("B", side=3, adj=0, line=1.5, font=2, cex=1.2)

dev.off()




## ---------------------------------------------------------
## Performance metrics
## ---------------------------------------------------------


## calculate posterior probability of each DILI category for each compound
post.prob <- t(apply(pr$ypred, 2, function(x) table(x)/length(x)))

## caclulate most likely DILI category for each compound
best.pred <- apply(post.prob, 1, which.max)

crosstabs <- xtabs( ~ best.pred + d$dili.sev)

## accuracy
sum(diag(crosstabs)) / 96

## balanced accuracy
((crosstabs[1, 1] / sum(crosstabs[, 1])) + 
    (crosstabs[2, 2] / sum(crosstabs[, 2])) + 
    (crosstabs[3, 3] / sum(crosstabs[, 3]))) / 3



## objects to store results of LOO predictions
post.samps.loo <- matrix(NA, nrow=15000, ncol=96)
post.eta.pred.loo <- matrix(NA, nrow=15000, ncol=96)
best.pred.loo <- numeric(96)

## LOO
for(i in 1:nrow(d2)){
    ## specify design matrix (intercept not needed; included as cutpoints)
    X.full <- model.matrix(~ 0 + (Spher + BSEP + THP1 + Glu + Glu.Gal + ClogP + BA)^2 +
                               log10.cmax, data=d2[-i, ])
    X.loo <- model.matrix(~ 0 + (Spher + BSEP + THP1 + Glu + Glu.Gal + ClogP + BA)^2 +
                              log10.cmax, data=d2[i, ])
    

    ## draw samples from posterior
    m.loo <- sampling(mod,
                   data=list(N=nrow(X.full),
                             P=ncol(X.full),
                             y=d2$dili.sev[-i],
                             X=X.full,
                             sigma_prior=1,
                             
                             make_pred = 1,
                             N_pred=1, 
                             X_pred=X.loo),
                   iter=10000, chains=3, seed=123, open_progress=FALSE)


    ## get posterior samples
    post.loo <- extract(m.loo)

    ## get linear predictor
    post.eta.pred.loo[, i] <- post.loo$eta_pred

    ## save posterior predictive samples
    post.samps.loo[, i] <- post.loo$ypred
    
    ## calculate posterior probability of each DILI category for each compound
    post.prob.loo <- t(apply(post.loo$ypred, 2, function(x) table(x)/length(x)))

    ## calculate most likely DILI category for each compound
    best.pred.loo[i] <- apply(post.prob.loo, 1, which.max)
}


## compared predicted vs. actual
crosstabs.loo <- xtabs( ~ best.pred.loo + d2$dili.sev)

## accuracy
sum(diag(crosstabs.loo)) / 96

## balanced accuracy
((crosstabs.loo[1, 1] / sum(crosstabs.loo[, 1])) + 
    (crosstabs.loo[2, 2] / sum(crosstabs.loo[, 2])) + 
    (crosstabs.loo[3, 3] / sum(crosstabs.loo[, 3]))) / 3


## compared predicted vs. actual for binary outcome (category 1 vs 2+3)
crosstabs.loo.binary <- xtabs( ~ I(best.pred.loo > 1) + I(d2$dili.sev > 1))

## accuracy
sum(diag(crosstabs.loo.binary)) / 96

## balanced accuracy
((crosstabs.loo.binary[1, 1] / sum(crosstabs.loo.binary[, 1])) + 
(crosstabs.loo.binary[2, 2] / sum(crosstabs.loo.binary[, 2]))) / 2


## sensitivity and specificity calculations
caret::confusionMatrix(data = factor(I(best.pred.loo > 1)), 
                       reference = factor(I(d2$dili.sev > 1)),
                       positive="TRUE")



## ---------------------------------------------------------
## Prediction on new compounds
## ---------------------------------------------------------


## generate design matrix
X.new <- model.matrix(~ 0 + (Spher + BSEP + THP1 + Glu + Glu.Gal + ClogP + BA)^2 +
                      log10.cmax, data=new.cpds.scaled)



## fit model to training data (again) and predict  test data
m2 <- sampling(mod,
               data=list(N=nrow(X),
                         P=ncol(X),
                         y=d2$dili.sev,
                         X=X,
                         sigma_prior=1,

                         make_pred = 1,
                         N_pred=nrow(X.new), # (predict test data)
                         X_pred=X.new),
              iter=10000, chains=3, seed=123)


## extract posterior samples
pr.test <- extract(m2)

## extract predicted values and convert to 0-1 scale
post.test <- invlogit(pr.test$eta_pred)


pdf("new_cpds_preds.pdf", height=5, width=10)
for (i in 1:nrow(new.cpds.scaled)){
    
    par(las=1,
        mar=c(4.5,1,3,1))

    layout(matrix(c(1,1,2,3), 2, 2))

    ## calculate all summary statistics
    res <- make.calcs(post.test[,i], pr.test$ypred[,i])
    
    ## First panel: density plot
    postplot(res$dens, main=new.cpds.scaled$Drug[i], percs=res$percs)
    
    ## Second panel: numeric summaries
    make.legend(res)
    
    ## Third panel: assay results
    par(mar=c(3,4.5,0.1,4.5))

    plot.dots(y=8, x=new.compounds[i, "Spher"], xlim=rev(c(2.04, 250)))
    
    par(new=TRUE)
    plot.dots(y=7, x=new.compounds[i, "BSEP"], xlim=rev(c(0.3, 1000)))

    par(new=TRUE)
    plot.dots(y=6, x=new.compounds[i, "THP1"], xlim=rev(c(0.01, 250)))
    
    par(new=TRUE)
    plot.dots(y=5, x=new.compounds[i, "Glu"], xlim=rev(c(11.8, 250)))

    par(new=TRUE)
    plot.dots(y=4, x=new.compounds[i, "Glu.Gal"], xlim=c(0.3, 5.2))

    par(new=TRUE)
    plot.dots(y=3, x=new.compounds[i, "ClogP"], xlim=c(-5.6, 9.7))

    par(new=TRUE)
    plot.dots(y=2, x=new.compounds[i, "log10.cmax"], xlim=c(-2, 3.0454))

    par(new=TRUE)
    plot.dots(y=1, x=new.compounds[i, "BA"], xlim=c(-1, 1))
    
    axis(2, at=8:1, labels=c("Spher","BSEP","THP1","Glu","Glu/Gal","ClogP","Cmax","BA"),
         tick=FALSE)
    axis(4, at=8:1, labels=c(new.compounds$Spher[i],
                             new.compounds$BSEP[i],
                             new.compounds$THP1[i],
                             new.compounds$Glu[i],
                             new.compounds$Glu.Gal[i],
                             new.compounds$ClogP[i],
                             signif(10^new.compounds$log10.cmax[i], 3),
                             new.compounds$BA[i]),
         tick=FALSE)
    axis(1, at=c(-1, 1), labels=c("Low risk","High risk"))
    mtext("Assay result", side=1, line=2)

}

dev.off()
