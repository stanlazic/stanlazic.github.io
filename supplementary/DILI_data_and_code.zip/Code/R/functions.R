## Function definitions


## inverse logistic function
invlogit <- function (x) {
    1/(1 + exp(-x))
}


## calculates peak (mode) of MCMC samples
chainmode <- function(chain , ... ) {
    dd <- density(chain , adjust=1.2, ...)
    dd$x[which.max(dd$y)]
}


## calculations for posterior plots
make.calcs <- function(post, ypred){
    ## post = draws from posterior for eta (on 0-1 scale)
    ## ypred = model predictions
    
    dens <- density(post, adjust=1.5, from=0, to=1)

    ## percent of distribution in each category (blue densities)
    percs <- c(mean(post < c1),
               mean(post > c1 & post < c2),
               mean(post > c2))

    ## posterior prediction for each category
    post.prob <- table(ypred)/length(ypred)

    ## summary statistics
    peak <- round(chainmode(post), 2)
    mn <- round(mean(post), 2)
    med <- round(median(post), 2)
    ci <- round(coda::HPDinterval(coda::as.mcmc(post)), 2)

    res <- list(dens=dens, post.prob=post.prob, percs=percs,
                peak=peak, mn=mn, med=med, ci=ci)

    return(res)
}


## makes posterior prediction plot
postplot <- function(dens, main, percs){
    ## dens = density of posterior, calculated from make.calcs()
    ## main = name of compound
    ## percs = % of distribution in each category, calculated from make.calcs()
    
    plot(dens, main=main, sub="", xlab="DILI severity",
         ylab="", xlim=c(0,1), type="n", ylim=c(0, 12), yaxt="n", xaxs="i")
    abline(v=c(c1, c2), lty=2)

    ## average profile for category 3 compounds
    lines(avg3$y ~ avg3$x)

    ## shade the density plot
    polygon(c(-0.01, dens$x, 1.01), c(0, dens$y, 0),
            col=rgb(0, 0, 1, 0.25), border="royalblue", lwd=2)

    ## add colour bars at the bottome
    rect(-10, -5, c1, 0, col="green4", border=NA)
    rect(c1, -5, c2, 0, col="darkgoldenrod", border=NA)
    rect(c2, -5, 10, 0, col="firebrick", border=NA)

    ## add percentages
    text(x = c1/2, y = -0.22, paste0(round(percs[1], 2) * 100, "%"),
         col="white", font=2)
    text(x = c1 + (c2 - c1)/2, y = -0.22, paste0(round(percs[2], 2) * 100, "%"),
         col="white", font=2)
    text(x = c2 + (1-c2)/2, y = -0.22, paste0(round(percs[3], 2) * 100, "%"),
         col="white", font=2)    
}


## Add posterior predictions and summary statistics to plot
make.legend <- function(res, true.category=NULL, cols=NULL){
    ## res = output (a list) from make.calcs()

    ## set up blank plot
    plot(c(0,1) , c(0,1), xlab="", ylab="", xaxt="n", yaxt="n", type="n", bty="n")

    ## posterior preditions
    legend("topleft", legend=round(c(res$post.prob),2),
           fill=c("green4","darkgoldenrod","firebrick"), title="Probability")

    ## add true category if available (omit when plotting test compounds)
    if(!is.null(true.category)){
        legend(y=1, x=0.30, legend=true.category, fill=cols,
               title="True category")
    }

    legend("topright", title="Summary stats",
           legend=c(paste0("Peak = ", res$peak),
                    paste0("Mean = ", res$mn),
                    paste0("Median = ", res$med),
                    paste0("95% CI = ", res$ci[1], " - ", res$ci[2])) )    
}


## add dots to output for assay results
plot.dots <- function(y, x, xlim){
    ## y = line to place the dot on
    ## x = assay and other predictor values
    
    plot(y=y, x=x,  xlim=xlim, ylim=c(1, 8),
         pch=21, col="royalblue", bg="lightblue", cex=1.2, bty="n", xaxt="n", yaxt="n",
         ylab="", xlab="",
         panel.first=abline(h=y, lty=2, col="darkgrey"))
}
