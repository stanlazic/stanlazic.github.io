.libPaths(c("C:\\Users\\kchd529\\Documents\\R\\R-3.3.1\\library"))
library(lattice)
library(grid)
library(rstan)
library(vioplot)
library(dplyr)
library(caret)

options(mc.cores = parallel::detectCores())

# read in user defined functions
source("funcs.R")


# read in data
d <- read.delim("QT_data.txt")

# make compound ID a factor
d$Compound <- factor(d$Compound)

# remove B2 agonists
d <- d[!d$Compound %in% c(9, 12), ]



# Figure 1
p1 <- dotplot(reorder(Compound, margin, median) ~ margin, data=d, groups=QT.label,
       scales=list(alternating=FALSE),
       ylab="Compound", xlab=Log[10]~(hERG~IC[50]/C[max]))

p2 <- xyplot(log.herg ~ log.cmax, data=d, groups=QT.label,
       type=c("g","p"), scales=list(alternating=FALSE),
       ylab=~Log[10]~hERG~IC[50], xlab=Log[10]~C[max],
       auto.key=list(columns=1, space="right"))

#png("figs/margin.png", height=4.5, width=10, res=100, units="in")
trellis.par.set(superpose.symbol=list(pch=c(16,17),
                                      col=c("royalblue","firebrick")),
                strip.background=list(col="lightgrey"),
                axis.components=list(right=list(tck=0), top=list(tck=0)))

print(p1, position=c(0, 0, 0.45, 1), more=TRUE)
print(p2, position=c(0.45, 0, 1, 1))
grid.text("A", x=0.05, y=0.95, gp=gpar(font=2, cex=1.2))
grid.text("B", x=0.50, y=0.95, gp=gpar(font=2, cex=1.2))
#dev.off()




## -------------------------------------------------------
## Fit several models to the data


# no parameter constraints
s1 <- stan("stan_models/logistic_mod.stan", chains=3, iter=10000,
          control=list(adapt_delta=0.95), seed=123, cores=3,
          data=list(N=nrow(d),
                    QT=d$QT.increase,
                    herg=d$log.herg,
                    cmax=d$log.cmax))



# with constraints
s2 <- stan("stan_models/logistic_mod_par_constr.stan", chains=3, iter=10000,
          control=list(adapt_delta=0.95), seed=123, cores=3,
          data=list(N=nrow(d),
                    QT=d$QT.increase,
                    herg=d$log.herg,
                    cmax=d$log.cmax))


# no cmax
s3 <- stan("stan_models/logistic_mod_no_cmax.stan", chains=3, iter=10000,
          control=list(adapt_delta=0.95), seed=123, cores=3,
          data=list(N=nrow(d),
                    QT=d$QT.increase,
                    herg=d$log.herg))


# parameter summary
print(s2, pars=c("b0","b1","b2","b3"))


# extract parameters
post1 <- extract(s1)
post2 <- extract(s2)
post3 <- extract(s3)

# extract theta values and convert to probability scale
theta1 <- invlogit(post1$theta)
theta2 <- invlogit(post2$theta)
theta3 <- invlogit(post3$theta)


## -------------------------------------------------------
## Violin plots

# prepare data for violin plot
preds1 <- theta1
colnames(preds1) <- d$uniq.cpd
ord1 <- order(apply(preds1, 2, mean))
preds1 <- preds1[, ord1]

preds2 <- theta2
colnames(preds2) <- d$uniq.cpd
ord2 <- order(apply(preds2, 2, mean))
preds2 <- preds2[, ord2]

preds3 <- theta3
colnames(preds3) <- d$uniq.cpd
ord3 <- order(apply(preds3, 2, mean))
preds3 <- preds3[, ord3]


# Figure 2
#png("figs/vioplots.png", height=6, width=7, res=100, units="in")
par(las=1,
    mfrow=c(1,2),
    mar=c(4, 4.5, 3, 2))


vioplot(preds3[,1],preds3[,2],
        preds3[,3],preds3[,4],
        preds3[,5],preds3[,6],
        preds3[,7],preds3[,8],
        preds3[,9],preds3[,10],
        preds3[,11],preds3[,12],
        preds3[,13],preds3[,14],
        preds3[,15],preds3[,16],
        preds3[,17],preds3[,18],
        preds3[,19],preds3[,20],
        preds3[,21],preds3[,22],
        preds3[,23],preds3[,24],
        preds3[,25],preds3[,26],
        preds3[,27],preds3[,28],
        preds3[,29],
        horizontal=TRUE, col=rgb(0, 0, 1, 0.25), drawRect=FALSE,
        names=colnames(preds3), border=rgb(0, 0, 1, 0.25))

points(c(1:29) ~ apply(preds3, 2, mean), pch="|", col="royalblue", cex=0.9)
points(c(1:29) ~ apply(preds3, 2, chainmode), pch=18, col="royalblue", cex=0.8)
title(~hERG~IC[50]~only )
mtext("Prob of QT increase", side=1, line=3)
axis(4, at=1:29, labels=ifelse(d$QT.increase[ord3] == 1, "+", "-"), tick=FALSE)
mtext("A", side=3, line=2, font=2, cex=1.2, adj=0)


vioplot(preds2[,1],preds2[,2],
        preds2[,3],preds2[,4],
        preds2[,5],preds2[,6],
        preds2[,7],preds2[,8],
        preds2[,9],preds2[,10],
        preds2[,11],preds2[,12],
        preds2[,13],preds2[,14],
        preds2[,15],preds2[,16],
        preds2[,17],preds2[,18],
        preds2[,19],preds2[,20],
        preds2[,21],preds2[,22],
        preds2[,23],preds2[,24],
        preds2[,25],preds2[,26],
        preds2[,27],preds2[,28],
        preds2[,29],
        horizontal=TRUE, col=rgb(0, 0, 1, 0.25), drawRect=FALSE,
        names=colnames(preds2), border=rgb(0, 0, 1, 0.25))

points(c(1:29) ~ apply(preds2, 2, mean), pch="|", col="royalblue", cex=0.9)
points(c(1:29) ~ apply(preds2, 2, chainmode), pch=18, col="royalblue", cex=0.8)
title(~hERG~IC[50]~and~C[max] )
mtext("Prob of QT increase", side=1, line=3)
axis(4, at=1:29, labels=ifelse(d$QT.increase[ord2] == 1, "+", "-"), tick=FALSE)
mtext("B", side=3, line=2, font=2, cex=1.2, adj=0)

#dev.off()



## -------------------------------------------------------
## comparing predictions with and without Cmax

confusionMatrix(as.numeric(colMeans(theta3) > 0.5), d$QT.increase,
                       positive="1")

confusionMatrix(as.numeric(colMeans(theta2) > 0.5), d$QT.increase,
                       positive="1")


# calculate Brier scores
bs3 <- brier.score.mcmc(theta3, d$QT.increase)
bs2 <- brier.score.mcmc(theta2, d$QT.increase)

# calculate posterior densities
dens.bs3 <- density(bs3, adjust=1.5)
dens.bs2 <- density(bs2, adjust=1.5)

# peak of distribution
chainmode(bs3)
chainmode(bs2)


# Figure 3
#png("figs/Brier_score.png", height=5, width=5, res=100, units="in")
par(mar=c(5,1,3,1))

plot(dens.bs3, ylim=c(0,70), lwd=3, col="royalblue", ylab="",
     xlab="", yaxt="n", main="Brier score", xlim=c(0, 0.4))
polygon(dens.bs3$x, dens.bs3$y, col=rgb(0, 0, 1, 0.25), border=NA)

lines(dens.bs2, lwd=3, col="green3")
polygon(dens.bs2$x, dens.bs2$y, col=rgb(0, 1, 0, 0.25), border=NA)

legend("topright", legend=c(expression(hERG~IC[50]~only),
                            expression(hERG~IC[50]~and~C[max])),
       cex=1, border=c("royalblue","green3"),
       fill=c(rgb(0, 0, 1, 0.25), rgb(0, 1, 0, 0.25)))

mtext(expression(phantom(0) %<-% Better~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~Worse %->% phantom(0)), side=1, line=2.5, font=2)

#dev.off()




## -------------------------------------------------------
## Compare with and with out parameter constraints

# Figure 4
#png("figs/parameter_constraints.png", height=4.5, width=8, res=100, units="in")
par(mfrow=c(1,2),
    las=1,
    mar=c(4.5, 5, 4, 0.5))
plot(post1$b1 ~ post1$b2, ylim=c(-11, 1), xlim=c(-1, 14),
     ylab=~beta[1]~(hERG~IC[50]), xlab=~beta[2]~(C[max]), cex=0.5,
     main=~No~parameter~constraints, col=rgb(0,0,1, 0.3))
abline(v=0, h=0, lty=2, col="firebrick")
mtext("A", side=3, line=2, font=2, cex=1.5, adj=0)

plot(post2$b1 ~ post2$b2, ylim=c(-11, 1), xlim=c(-1, 14),
     ylab=~beta[1]~(hERG~IC[50]), xlab=~beta[2]~(C[max]), cex=0.5,
     main=~beta[1] < 0~~and~~beta[2] > 0, , col=rgb(0,0,1, 0.3))
abline(v=0, h=0, lty=2, col="firebrick")
mtext("B", side=3, line=2, font=2, cex=1.5, adj=0)

#dev.off()





## -------------------------------------------------------
## Prior information for parameters

# read in Gintant data
gin <- read.delim("../data/Gintant_data.txt")

# log-transform values
gin$log.herg <- log10(gin$hERG_IC50)
gin$log.cmax <- log10(gin$Cmax)

gint <- glm(QT_inc ~ log.herg*log.cmax, data=gin, family=binomial)
summary(gint) # incorporate these values into the prior


s4 <- stan("stan_models/logistic_mod_prior_info.stan", chains=3, iter=10000,
          control=list(adapt_delta=0.95), seed=123, cores=3,
          data=list(N=nrow(d),
                    QT=d$QT.increase,
                    herg=d$log.herg,
                    cmax=d$log.cmax))

# compare parameter values
print(s2, pars=c("b0","b1","b2","b3"))
print(s4, pars=c("b0","b1","b2","b3"))

# extract parameters
post4 <- extract(s4)

# extract theta values and convert to probability scale
theta4 <- invlogit(post4$theta)


# calculate posterior densities
dens2.b0 <- density(post2$b0, adjust=1.5)
dens2.b1 <- density(post2$b1, adjust=1.5, to=0)
dens2.b2 <- density(post2$b2, adjust=1.5, from=0)
dens2.b3 <- density(post2$b3, adjust=1.5)

dens4.b0 <- density(post4$b0, adjust=1.5)
dens4.b1 <- density(post4$b1, adjust=1.5, to=0)
dens4.b2 <- density(post4$b2, adjust=1.5, from=0)
dens4.b3 <- density(post4$b3, adjust=1.5)


# Figure 5
#png("figs/Prior_info.png", height=7, width=7, res=100, units="in")
par(mar=c(4,2,3,1),
    mfrow=c(2,2))
plot(dens2.b0, lwd=3, col="royalblue", ylab="",
     xlab=~beta[0], yaxt="n", main="", ylim=c(0,0.3))#, , xlim=c(0, 0.3))
polygon(dens2.b0$x, dens2.b0$y, col=rgb(0, 0, 1, 0.25), border=NA)
title(~Intercept)

lines(dens4.b0, lwd=3, col="green3")
polygon(dens4.b0$x, dens4.b0$y, col=rgb(0, 1, 0, 0.25), border=NA)

lines(dnorm(seq(-2, 30, 0.01), 0, 10) ~ seq(-2, 30, 0.01), lwd=3, col="firebrick")
polygon(c(-2,seq(-2, 30, 0.01)), c(0,dnorm(seq(-2, 30, 0.01), 0, 10)),
        col=rgb(1, 0, 0, 0.25), border=NA)

legend("topright", legend=c("Gintant prior", "AZ Data", "AZ with Gintant"),
       cex=1, border=c("firebrick","royalblue","green3"),
       fill=c(rgb(1, 0, 0, 0.25), rgb(0, 0, 1, 0.25), rgb(0, 1, 0, 0.25)))


plot(dens2.b1, lwd=3, col="royalblue", ylab="",
     xlab=~beta[1], yaxt="n", main="", ylim=c(0,0.6))
polygon(dens2.b1$x, dens2.b1$y, col=rgb(0, 0, 1, 0.25), border=NA)
title(~hERG~IC[50])

lines(dens4.b1, lwd=3, col="green3")
polygon(dens4.b1$x, dens4.b1$y, col=rgb(0, 1, 0, 0.25), border=NA)

lines(dnorm(seq(-12, 0, 0.01), -1.37, 0.51*4) ~ seq(-12, 0, 0.01), lwd=3, col="firebrick")
polygon(c(-12,seq(-12, 0, 0.01)), c(dnorm(seq(-12, 0, 0.01), -1.37, 0.51*4), 0),
        col=rgb(1, 0, 0, 0.25), border=NA)


plot(dens2.b2, lwd=3, col="royalblue", ylab="",
     xlab=~beta[2], yaxt="n", main="", ylim=c(0,0.5))
polygon(dens2.b2$x, dens2.b2$y, col=rgb(0, 0, 1, 0.25), border=NA)
title(~C[max])

lines(dens4.b2, lwd=3, col="green3")
polygon(dens4.b2$x, dens4.b2$y, col=rgb(0, 1, 0, 0.25), border=NA)

lines(dnorm(seq(0, 30, 0.01), 0.757, 0.778*4) ~ seq(0, 30, 0.01), lwd=3, col="firebrick")
polygon(c(0,seq(0, 30, 0.01)), c(0,dnorm(seq(0, 30, 0.01), 0.757, 0.778*4)),
        col=rgb(1, 0, 0, 0.25), border=NA)

plot(dens2.b3, lwd=3, col="royalblue", ylab="",
     xlab=~beta[3], yaxt="n", main="", ylim=c(0,1.2))
polygon(dens2.b3$x, dens2.b3$y, col=rgb(0, 0, 1, 0.25), border=NA)
title(~hERG~IC[50] %*% C[max]~~interaction)

lines(dens4.b3, lwd=3, col="green3")
polygon(dens4.b3$x, dens4.b3$y, col=rgb(0, 1, 0, 0.25), border=NA)

lines(dnorm(seq(-5, 2, 0.01), -0.345, 0.185*4) ~ seq(-5, 2, 0.01), lwd=3, col="firebrick")
polygon(c(-5,seq(-5, 2, 0.01)), c(dnorm(seq(-5, 2, 0.01), -0.345, 0.185*4), 0),
        col=rgb(1, 0, 0, 0.25), border=NA)

#dev.off()

# compare predictions with and without prior info
confusionMatrix(as.numeric(colMeans(theta2) > 0.5), d$QT.increase,
                positive="1")

confusionMatrix(as.numeric(colMeans(theta4) > 0.5), d$QT.increase,
                positive="1")




## -------------------------------------------------------
##  Make decision boundary

# Sequence of hERG and Cmax values for plot
herg.levels <- seq(-1, 5, length.out=30)
cmax.levels <- seq(-3, 3, length.out=30)

# make into grid of values
xpred <- expand.grid(log.herg = herg.levels,
                     log.cmax = cmax.levels)

# calculate decision boundary for model without prior info
xpred$y1 <- with(xpred,
                 invlogit(mean(post2$b0) + mean(post2$b1)*log.herg +
                               mean(post2$b2)*log.cmax +
                               mean(post2$b3)*log.herg*log.cmax))

# calculate decision boundary for model with prior info
xpred$y2 <- with(xpred,
                 invlogit(mean(post4$b0) + mean(post4$b1)*log.herg +
                               mean(post4$b2)*log.cmax +
                               mean(post4$b3)*log.herg*log.cmax))


# matrix to store values from sampled boundaries
post.pred2 <- matrix(NA, nrow=900, ncol=50)
post.pred4 <- matrix(NA, nrow=900, ncol=50)

# calculate decision boundaries consistent with data (draws from posterior)
for (i in 1:50){
    post.pred2[,i] <- with(xpred,
                           invlogit(post2$b0[i] + post2$b1[i]*log.herg +
                                         post2$b2[i]*log.cmax +
                                         post2$b3[i]*log.herg*log.cmax))

    post.pred4[,i] <- with(xpred,
                           invlogit(post4$b0[i] + post4$b1[i]*log.herg +
                                         post4$b2[i]*log.cmax +
                                         post4$b3[i]*log.herg*log.cmax))
}



# calculate Brier scores
bs2 <- brier.score.mcmc(theta2, d$QT.increase)
bs4 <- brier.score.mcmc(theta4, d$QT.increase)

dens.bs2 <- density(bs2, adjust=1.5)
dens.bs4 <- density(bs4, adjust=1.5)


# Figure 6
#png("figs/Gintant.png", height=4.5, width=12, res=100, units="in")

par(mfrow=c(1,3),
    mar=c(4.5, 4, 3, 0.5),
    las=1, cex=1)

## 1st graph
plot(log.herg ~ log.cmax, data=d, type="n", ylim=c(-1,5), xlim=c(-3,3),
     xlab=~Log[10]~C[max], ylab=~Log[10]~hERG~IC[50],
     main="AZ data")

filter(d, QT.increase ==1 ) %>%
    points(log.herg ~ log.cmax, data=., col="firebrick", pch=17)

filter(d, QT.increase == 0 ) %>%
    points(log.herg ~ log.cmax, data=., col="royalblue", pch=16)


for(i in 1:50){
    contour(y=herg.levels, x=cmax.levels, z=matrix(post.pred2[,i],
             nrow=30, ncol=30, byrow=TRUE),
        add=TRUE, levels=0.5, drawlabels=FALSE, lwd=1, lty=1, col=rgb(0,0,0,0.25))
}

contour(y=herg.levels, x=cmax.levels, z=matrix(xpred$y1, nrow=30, ncol=30, byrow=TRUE),
        add=TRUE, levels=0.5, drawlabels=FALSE, lwd=2)


legend("bottomright", legend=c("No increase","QT increase"),
       cex=1, col=c("royalblue","firebrick"), pch=c(16,17))


## 2nd graph
plot(log.herg ~ log.cmax, data=d, type="n", ylim=c(-1,5), xlim=c(-3,3),
     xlab=~Log[10]~C[max], ylab=~Log[10]~hERG~IC[50],
     main="AZ data with Gintant prior")

filter(d, QT.increase ==1 ) %>%
    points(log.herg ~ log.cmax, data=., col="firebrick", pch=17)

filter(d, QT.increase == 0 ) %>%
    points(log.herg ~ log.cmax, data=., col="royalblue", pch=16)


for(i in 1:50){
    contour(y=herg.levels, x=cmax.levels, z=matrix(post.pred4[,i],
             nrow=30, ncol=30, byrow=TRUE),
        add=TRUE, levels=0.5, drawlabels=FALSE, lwd=1, lty=1, col=rgb(0,0,0,0.25))
}

contour(y=herg.levels, x=cmax.levels, z=matrix(xpred$y2, nrow=30, ncol=30, byrow=TRUE),
        add=TRUE, levels=0.5, drawlabels=FALSE, lwd=2)

## 3rd graph
plot(dens.bs2, ylim=c(0,40), lwd=3, col="royalblue", ylab="",
     xlab="", yaxt="n", main="Brier score", xlim=c(0, 0.3))
polygon(dens.bs2$x, dens.bs2$y, col=rgb(0, 0, 1, 0.25), border=NA)

lines(dens.bs4, lwd=3, col="green3")
polygon(dens.bs4$x, dens.bs4$y, col=rgb(0, 1, 0, 0.25), border=NA)

legend("topright", legend=c("AZ data", "AZ with Gintant"),
       cex=1, border=c("royalblue","green3"),
       fill=c(rgb(0, 0, 1, 0.25), rgb(0, 1, 0, 0.25)))

mtext(expression(phantom(0) %<-% Better~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~Worse %->% phantom(0)), side=1, line=2.5, font=2)

#dev.off()






## -------------------------------------------------------
## Predicting risk for a new compound



# sequence of Cmax levels at which predictions are made
cmax.levels <- seq(-3, 3.5, length.out=30)

# expand into grid, with only on hERG value
newdata <- expand.grid(log.herg = 0.8, # fixed hERG (6.31 uM = 0.8 on log10 scale)
                      log.cmax = cmax.levels)


# matrix to store results
y.pred <- matrix(NA, nrow=15000, ncol=length(cmax.levels))

# calculate predictions
for (i in 1:15000){
    for (j in 1:length(cmax.levels)){
        y.pred[i,j] <- with(newdata,
                            invlogit(post2$b0[i] + post2$b1[i]*log.herg[j] +
                                     post2$b2[i]*log.cmax[j] +
                                     post2$b3[i]*log.herg[j]*log.cmax[j]))
    }
}



# means
y.means <- colMeans(y.pred)

#  90% CI
ci <- apply(y.pred, 2, quantile, probs=c(0.05, 0.95))

# calculate densities at two values of cmax
y.dens <- density(y.pred[,7], adjust=1.5, from=0, to=1) # log.cmax=-1.655, cmax=0.02
y.dens2 <- density(y.pred[,13], adjust=1.5, from=0, to=1) # log.cmax=-0.3103448, cmax=0.5



# calculate summaries for posterior
mean(y.pred[, 7])
median(y.pred[, 7])
chainmode(y.pred[, 7])
mean(y.pred[, 7] > 0.5)


mean(y.pred[, 13])
median(y.pred[, 13])
chainmode(y.pred[, 13])
mean(y.pred[, 13] > 0.5)


# Figure 7
#png("figs/predictions.png", height=4.5, width=13, res=100, units="in")
par(mfrow=c(1,3),
    mar=c(4.5, 4.5, 2.5, 0.3),
    las=1, cex=1)
plot(y.means ~ cmax.levels, type="n", xlab=~Log[10]~C[max], ylab="Prob of QT increase",
     main=expression(paste(hERG~IC[50]==6.31~mu, "M", sep="")))

polygon(c(cmax.levels, rev(cmax.levels)),
        c(ci[1,], rev(ci[2,])), col=rgb(0,0,1, 0.2), border=NA)
lines(y.means ~ cmax.levels, col="royalblue")
abline(v=cmax.levels[c(7,13)], lty=2)
mtext("A", side=3, line=1, adj=0, cex=1.2, font=2)


plot(y.dens, lwd=3, col="royalblue", ylab="",
     xlab="Prob of QT increase", yaxt="n", ylim=c(0,8.5),
     expression(paste(C[max]==0.02~mu, "M", sep="")))

polygon(c(0, y.dens$x), c(0, y.dens$y), col=rgb(0, 0, 1, 0.25), border=NA)
mtext("B", side=3, line=1, adj=0, cex=1.2, font=2)

legend("topright", legend=c("Mean = 0.12", "Median = 0.08", "Peak = 0.02",
                            "P > 0.5 = 0.02"))


plot(y.dens2, lwd=3, col="royalblue", ylab="",
     xlab="Prob of QT increase", yaxt="n",
     expression(paste(C[max]==0.50~mu, "M", sep="")), ylim=c(0,8.5))
polygon(c(y.dens2$x,1), c(y.dens2$y,0), col=rgb(0, 0, 1, 0.25), border=NA)
mtext("C", side=3, line=1, adj=0, cex=1.2, font=2)

legend("topleft", legend=c("Mean = 0.91", "Median = 0.94", "Peak = 0.98",
                            "P > 0.5 = 0.99"))

#dev.off()




## -------------------------------------------------------
## Ranking compounds


# simulate new data
set.seed(123)

# generate new hERG and Cmax values for 10 compounds
newdat <- data.frame(herg=runif(10, 0, 3), cmax=runif(10, -2, 2))


# matrix to store results
newpost <- matrix(NA, nrow=15000, ncol=10)

# calculate predictions based on main model (s2)
for(i in 1:15000){
    for(j in 1:10){
        newpost[i, j] <-  post2$b0[i] + post2$b1[i]*newdat$herg[j] +
            post2$b2[i]*newdat$cmax[j] + post2$b3[i]*newdat$herg[j]*newdat$herg[j]
    }
}


# for each draw from posterior, calculate rank of each compound
rank <- apply(newpost, 1, rank)

# calculate number of times compound was ranked first
best <- rowMeans(rank == 1)
names(best) <- LETTERS[1:10] # add letters to identify compound

# calculate distribution of ranks for two compounds
cpd.h <- c(table(rank[8,])/ncol(rank), 0, 0) # Compound H
names(cpd.h) <- 1:10

cpd.b <- c(0,0, table(rank[2,])/ncol(rank), 0, 0) # Compound B
names(cpd.b) <- 1:10


# Figure 8
#png("figs/test_compounds.png", height=7, width=7, res=100, units="in")
par(las=1,
    mar=c(4.5,4.5,3.5,1),
    mfrow=c(2,2),
    cex=0.9)

# A
plot(herg ~ cmax, data=newdat,  ylim=c(-1,5), xlim=c(-3,3),
     xlab=~Log[10]~C[max], ylab=~Log[10]~hERG~IC[50], main="Test compounds",
     pch=16, col="royalblue")
text(y=newdat$herg, x=newdat$cmax, labels=LETTERS[1:10], pos=3, offset=0.5)

contour(y=herg.levels, x=cmax.levels, z=matrix(xpred$y1, nrow=30, ncol=30, byrow=TRUE),
        add=TRUE, levels=0.5, drawlabels=FALSE, lwd=2)
mtext("A", side=3, line=2, font=2, cex=1.5, adj=0)

# B
barplot(best, horiz=TRUE, xlim=c(0,1), xlab="P(Best)",
        main="Best compound")
mtext("B", side=3, line=2, font=2, cex=1.5, adj=0)

# C
barplot(cpd.h, ylim=c(0,1), main="Compound H", xlab="Rank", ylab="P(rank)")
mtext("C", side=3, line=2, font=2, cex=1.5, adj=0)

# D
barplot(cpd.b, ylim=c(0,1), main="Compound B", xlab="Rank", ylab="P(rank)")
mtext("D", side=3, line=2, font=2, cex=1.5, adj=0)

#dev.off()
