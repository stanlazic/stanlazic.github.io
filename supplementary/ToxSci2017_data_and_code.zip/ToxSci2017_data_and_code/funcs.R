
# inverse logistic transformation
invlogit <- function (x) {
    1/(1 + exp(-x))
}


# calculates peak of distribution
chainmode <- function( chain , ... ) {
    dd <- density(chain , ...)
    dd$x[which.max(dd$y)]
}


# brier for MCMC samples
brier.score.mcmc <- function(pred, obs){
    n <- length(obs)
    res <- apply(pred, 1, function(x) { sum((x - obs)^2)/n } )
    return(res)
}
